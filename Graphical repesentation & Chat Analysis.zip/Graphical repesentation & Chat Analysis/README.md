<!-- How to Run -->
## in Terminal run cmd
streamlit run app.py
